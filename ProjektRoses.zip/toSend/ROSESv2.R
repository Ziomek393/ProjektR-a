
library(haven)
library(dplyr)
library(data.table)
library(stringr)
library(readxl)
roses <- read_sav("ROSES.sav")
woj <- read.csv2("woj.csv",fileEncoding = "UTF-8")
coord <- read_xlsx("Koordynaty.xlsx")

### Porządzkuję bałagan z miastami, żeby móc pogrupować do województw
# Czyszczenie długości i szerokości geograficznej
coord <- coord[2:2319,] %>%
  mutate(Długość1 = str_remove(Długość, "\'E$"), Szerokość1 = str_remove(Szerokość, "\'N$")) %>% 
  mutate(Długość1 = str_replace(Długość1, "°", "\\."), Szerokość1 = str_replace(Szerokość1, "°", "\\.")) %>% 
  mutate(Długość1 = as.numeric(Długość1), Szerokość1 = as.numeric(Szerokość1))
coord <- coord %>% 
  select(Miejscowość,Długość=Długość1,Szerokość=Szerokość1)

# Zaokrąglanie dł. i szer. w Roses

r1 <- roses %>% 
  mutate(LocationLatitude = round(as.numeric(LocationLatitude), 4), 
         LocationLongitude = round(as.numeric(LocationLongitude), 4)) %>% 
  filter(LocationLongitude >0) %>% 
  select(ResponseId,LocationLongitude, LocationLatitude)


r2 <- merge.data.frame(r1, coord, by = NULL)
r22<- r2 %>% group_by(ResponseId) %>%
  mutate(min_d = min((LocationLatitude-Szerokość)^2+(LocationLongitude - Długość)^2,na.rm=TRUE)) %>% 
  mutate(d=(LocationLatitude-Szerokość)^2+(LocationLongitude - Długość)^2)
r23 <- r22 %>% 
  filter(min_d==d & min_d <5) %>%
  select(ResponseId,Miejscowość)
View(r23)
kordadd <- read_xlsx("Koordynaty_add1.xlsx")
View(kordadd)
coordimportant <- read_xlsx("exportImportant.xlsx")
View(coordimportant)
kordadd <- kordadd %>% 
  filter(Województwo>0) %>% 
  select(ResponseId, Województwo)

r3 <- r23 %>% 
  left_join(coordimportant, by.x="Miejscowość",by.y="Miejscowość")
View(r3)

r4 <- r3 %>% 
  filter(nazwa.województwa>0) %>% 
  select(ResponseId,Województwo=nazwa.województwa)

sum_woj_resp_id <- rbind(r4,kordadd)
roses_q <- left_join(sum_woj_resp,roses,by="ResponseId")

write.csv2(sum_woj_resp,"sum_woj_resp.csv")
write.csv2(roses_q, "roses_q.csv")
roses_q1 <- read.csv2("roses_q.csv")
View(roses_q1)



### Plan na Rurze ###
# Jakie pytania chcemy zada?? 
# Basic theme - podział na województwa
# 1. Mapa Polski - Współczynnik wykorzystania pomocy naukowych (Q13) + liczba recordów
# 2. Punktowy - "x" zainteresowanie uczniów przedmiotami, "y" wykorzystanie pomocy (a. jednostki, b.woj)
# 3. Słupkowy - ranking pomocy naukowych (Q13)

