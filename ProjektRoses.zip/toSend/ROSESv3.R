install.packages("sf")
library(sf)
library(haven)
library(dplyr)
library(data.table)
library(stringr)
library(readxl)
roses <- read_sav("ROSES.sav")
woj <- read.csv2("woj.csv",fileEncoding = "UTF-8")
coord <- read_xlsx("Koordynaty.xlsx")
kordadd <- read_xlsx("Koordynaty_add1.xlsx")
coordimportant <- read_xlsx("exportImportant.xlsx")
kordadd <- kordadd %>% 
  filter(Województwo>0) %>% 
  select(ResponseId, Województwo)

### Porządzkuję bałagan z miastami, żeby móc pogrupować do województw
# Czyszczenie długości i szerokości geograficznej
coord <- coord[2:2319,] %>%
  mutate(Długość1 = str_remove(Długość, "\'E$"), Szerokość1 = str_remove(Szerokość, "\'N$")) %>% 
  mutate(Długość1 = str_replace(Długość1, "°", "\\."), Szerokość1 = str_replace(Szerokość1, "°", "\\.")) %>% 
  mutate(Długość1 = as.numeric(Długość1), Szerokość1 = as.numeric(Szerokość1))
coord <- coord %>% 
  select(Miejscowość,Długość=Długość1,Szerokość=Szerokość1)

# Zaokrąglanie dł. i szer. w Roses

r1 <- roses %>% 
  mutate(LocationLatitude = round(as.numeric(LocationLatitude), 4), 
         LocationLongitude = round(as.numeric(LocationLongitude), 4)) %>% 
  filter(LocationLongitude >0) %>% 
  select(ResponseId,LocationLongitude, LocationLatitude)

r2 <- merge.data.frame(r1, coord, by = NULL) %>%
  group_by(ResponseId) %>%
  mutate(min_d = min((LocationLatitude-Szerokość)^2+(LocationLongitude - Długość)^2,na.rm=TRUE)) %>% 
  mutate(d=(LocationLatitude-Szerokość)^2+(LocationLongitude - Długość)^2) %>% 
  filter(min_d==d & min_d <5) %>%
  select(ResponseId,Miejscowość) %>% 
  left_join(coordimportant, by.x="Miejscowość",by.y="Miejscowość") %>% 
  filter(is.null(nazwa.województwa)==FALSE) %>% 
  select(ResponseId,Województwo=nazwa.województwa) %>% 
  bind_rows(kordadd)
View(r2)
roses_q <- left_join(r2,roses,by="ResponseId")
write.csv2(sum_woj_resp,"sum_woj_resp1.csv")
write.csv2(roses_q, "roses_q1.csv")
#roses_q <- read.csv2("roses_q.csv")
roses_q1 <- read.csv2("roses_q1.csv")



### Plan na Rurze ###
# UZUPEŁNIĆ coordimportant - brakuje kilku miejscowości
# Jakie pytania chcemy zada?? 
# Basic theme - podział na województwa
# 1. Mapa Polski - Współczynnik wykorzystania pomocy naukowych (Q13) + liczba recordów
# 2. Punktowy - "x" zainteresowanie uczniów przedmiotami, "y" wykorzystanie pomocy (a. jednostki, b.woj)
# 3. Słupkowy - ranking pomocy naukowych (Q13)


# Mapa
polandmap <- read_sf("wojewodztwa.shp")
