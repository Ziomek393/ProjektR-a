library(forcats)
library(dplyr)
library(ggplot2)
library(stringr)
library(sf)
library(haven)

roseslabels <- read_sav("roses.sav")
roses <- read.csv2("roses_q1.csv", encoding = "UTF-8")
# woj <- read.csv2("sum_woj_resp.csv")

polandmap <- read_sf("wojewodztwa.shp")

polskamap <- polandmap %>% select(name = JPT_NAZWA_, geometry) %>% arrange(name)

ggplot(data = polskamap) + geom_sf()

# pytania <- roses[, c(2, 163:172)]

roses$ilena <- rowSums(is.na(roses[,163:172]))

# roses %>% filter(is.na(Województwo) == FALSE) %>%
#  mutate(Województwo = str_remove(Województwo, " ")) %>% 
#  group_by(Województwo) %>% summarise(Count = n(), Coeff = sum(colMeans( roses[,163:172], na.rm = TRUE )) )

tmp <- roses %>% filter(is.na(Województwo) == FALSE) %>%
  mutate(Województwo = str_remove(Województwo, " ")) %>% 
  group_by(ResponseId) %>% 
  mutate(wsp = sum(Q13_1, Q13_2, Q13_3, Q13_4, Q13_5, Q13_6, Q13_7, Q13_8, Q13_9, Q13_10, na.rm = TRUE), 
         Cunt = 10 - ilena, Meanvalue = wsp/Cunt) %>% 
  ungroup() %>% group_by(Województwo) %>% 
  mutate(MeanWoj = mean(Meanvalue, na.rm = TRUE))

# Ramka do wykresu Polski

tmp %>% select(Województwo, MeanWoj) %>% 
  distinct(Województwo, .keep_all = TRUE) %>% 
  arrange(Województwo) %>% 
  mutate(Województwo = str_to_lower(Województwo)) %>% 
  inner_join(polskamap, by.x = Województwo, by.y = name)

polskamap
